/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import chatapp.Login;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class LoginTest {
private Login login;
@BeforeEach
public void setUp() {
login = new Login();
login.registerUser("Kyle", "Loves", "kyl_1", "Ch&&sec@ke99!", "+27838968976");
}
@Test
public void testCheckUserNameCorrectlyFormatted() {
assertTrue(login.checkUserName("kyl_1"));
}
@Test
public void testCheckUserNameIncorrectlyFormatted() {
assertFalse(login.checkUserName("kyle!!!!!!!"));
}
@Test
public void testPasswordMeetsComplexity() {
assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
}
@Test
public void testPasswordDoesNotMeetComplexity() {
assertFalse(login.checkPasswordComplexity("password"));
}
@Test
public void testCellPhoneNumberCorrectlyFormatted() {
assertTrue(login.checkCellPhoneNumber("+27838968976"));
}
@Test
public void testCellPhoneNumberIncorrectlyFormatted() {
assertFalse(login.checkCellPhoneNumber("08966553"));
}
@Test
public void testLoginSuccessful() {
assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
}
@Test
public void testLoginFailed() {
assertFalse(login.loginUser("kyl_1", "wrongpassword"));
}
@Test
public void testReturnLoginStatusSuccess() {
String expected = "Welcome Kyle, Loves it is great to see you again.";
assertEquals(expected, login.returnLoginStatus(true));
}
@Test
public void testReturnLoginStatusFailure() {
String expected = "Username or password incorrect, please try again.";
assertEquals(expected, login.returnLoginStatus(false));
}
}
