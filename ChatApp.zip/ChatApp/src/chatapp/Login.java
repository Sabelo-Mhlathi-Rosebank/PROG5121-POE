/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp;

import java.util.regex.Pattern;

public class Login {
private String registeredFirstName;
private String registeredLastName;
private String registeredUsername;
private String registeredPassword;
private String registeredCellNumber;
public Login() {
this.registeredFirstName = "";
this.registeredLastName = "";
this.registeredUsername = "";
this.registeredPassword = "";
this.registeredCellNumber = "";
}

public boolean checkUserName(String username) {
if (username == null) return false;
return username.contains("_") && username.length() <= 5;
}
public boolean checkPasswordComplexity(String password) {
if (password == null || password.length() < 8) {
return false;
}
boolean hasCapital = password.matches(".*[A-Z].*");
boolean hasNumber = password.matches(".*[0-9].*");
boolean hasSpecial = password.matches(".*[!@#$%^&*()+\\-=\\[\\]{};':\"\\\\|,.<>/?].*");
return hasCapital && hasNumber && hasSpecial;
}

public boolean checkCellPhoneNumber(String cellNumber) {
if (cellNumber == null) return false;
String regex = "^\\+27[0-9]{9}$";
return Pattern.matches(regex, cellNumber);
}

public String registerUser(String firstName, String lastName, String username, String password,
String cellNumber) {
if (!checkUserName(username)) {
return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
}
if (!checkPasswordComplexity(password)) {
return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
}
if (!checkCellPhoneNumber(cellNumber)) {
return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
}

this.registeredFirstName = firstName;
this.registeredLastName = lastName;
this.registeredUsername = username;
this.registeredPassword = password;
this.registeredCellNumber = cellNumber;
return "Username successfully captured.\nPassword successfully captured.\nCell number successfully captured.";
}

public boolean loginUser(String username, String password) {
if (username == null || password == null) return false;
return username.equals(this.registeredUsername) && password.equals(this.registeredPassword);
}

public String returnLoginStatus(boolean loginSuccess) {
if (loginSuccess) {
return "Welcome " + registeredFirstName + ", " + registeredLastName + " it is great to see you again.";
} else {
return "Username or password incorrect, please try again.";
}
}

public String getRegisteredFirstName() { return registeredFirstName; }
public String getRegisteredLastName() { return registeredLastName; }
public String getRegisteredUsername() { return registeredUsername; }
public String getRegisteredPassword() { return registeredPassword; }
public String getRegisteredCellNumber() { return registeredCellNumber; }
}
