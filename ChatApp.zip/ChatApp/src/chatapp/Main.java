/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chatapp;

import java.util.Scanner;
public class Main {
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
Login appLogin = new Login();
System.out.println("==========================================");
System.out.println(" WELCOME TO THE CHAT APP REGISTRATION ");
System.out.println("==========================================");
System.out.print("Enter First Name: ");
String firstName = scanner.nextLine();
System.out.print("Enter Last Name: ");
String lastName = scanner.nextLine();
System.out.print("Enter Username (must have '_' and max 5 chars): ");
String username = scanner.nextLine();
System.out.print("Enter Password (min 8 chars, 1 uppercase, 1 digit, 1 special char): ");
String password = scanner.nextLine();
System.out.print("Enter Cell Phone Number (e.g., +27838968976): ");
String cellNumber = scanner.nextLine();
System.out.println("\n--- REGISTRATION STATUS ---");
String registrationMsg = appLogin.registerUser(firstName, lastName, username, password,cellNumber);
System.out.println(registrationMsg);
if (appLogin.checkUserName(username) &&
appLogin.checkPasswordComplexity(password) &&
appLogin.checkCellPhoneNumber(cellNumber)) {
System.out.println("\n==========================================");
System.out.println(" USER LOGIN ");
System.out.println("==========================================");
System.out.print("Enter Username: ");
String inputUser = scanner.nextLine();
System.out.print("Enter Password: ");
String inputPass = scanner.nextLine();
boolean isSuccess = appLogin.loginUser(inputUser, inputPass);
String loginStatusMsg = appLogin.returnLoginStatus(isSuccess);
System.out.println("\n--- LOGIN STATUS ---");
System.out.println(loginStatusMsg);
} else {
System.out.println("\nRegistration failed. Please restart the application and enter valid details.");
}
scanner.close();
}
}